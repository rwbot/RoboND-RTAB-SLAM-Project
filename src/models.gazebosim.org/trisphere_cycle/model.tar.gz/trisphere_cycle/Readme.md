To regenerate the model.sdf from the erb template:
~~~
erb -T 1 model.sdf.erb > model.sdf
~~~
