To regenerate the model.sdf from the erb template:
~~~
erb model.rsdf > model.sdf
~~~
